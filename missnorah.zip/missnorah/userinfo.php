<!DOCTYPE html>

<?php session_start(); ?>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  </head>
  <body style="background-color:#000;">
<center>
    <?php

    if (isset($_SESSION["admin_email"])) {


      $email = $_SESSION["admin_email"];

      $photo = $_SESSION['admin_pic'];



     ?>
     <center>

<h2 style="font-family:sans-serif;color:#fff;">The email address


  <b style="color:white;font-size:16pt;text-decoration:underline;"><?php echo $email; ?></b>


   are successfully authenticated By Github</h2>
   <br><br>

 </center>
<div class="col-lg-12" style="border:1px solid black;">





<h3 style="color:#fff;">Image : <img src="<?php echo $photo; ?>" alt="" style="border-radius:100px;width:100px;"> </h3>

<h3 style="color:#fff;">email : <?php echo $email; ?> </h3>

</div>

<?php } ?>


<a href="userinfo.php?l=logout" class="btn btn-lg btn-danger" style="margin-top:100px;border:3px solid white;">Log out</a>



</center>
<center>
<div class="" style="background-color:#fff;width:300px;padding-top:10px;padding-bottom:10px;margin-top:30px;font-weight:bold;">


<p style="color:#000;">Email : <?php echo $email; ?></p>
<p style="color:#000;">Authentication day : <?php echo date("l"); ?></p>
<p style="color:#000;">Authentication Date : <?php echo date("Y/m/d"); ?></p>
<p style="color:#000;">Authentication Time : <?php echo date("h:i:sa"); ?></p>

</div>

</center>
<br>
<hr>


<br><br>
</body>
</html>


<?php


if (isset($_GET['l'])) {

      session_destroy();
      header("location:http://localhost/missnorah/frontend.php");


}





 ?>
