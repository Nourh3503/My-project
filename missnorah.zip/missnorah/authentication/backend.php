<?php

    session_start();
    require_once('includes/hybridauth/src/autoload.php');

    if(isset($_SESSION["admin_email"]))
    {
        header("location:http://localhost/missnorah/userinfo.php");
    }


// we are using these built in functions of composer

    use Hybridauth\Exception\Exception;
    use Hybridauth\Hybridauth;
    use Hybridauth\HttpClient;

    // this is the end of built in function of composer

    if($_GET["key"] == "GitHub")
    {
        $provider = $_GET["key"];
        $config = [
            'callback' => "http://localhost/missnorah/authentication/backend.php?key=$provider",
            'providers' => [
                'GitHub' => [
                    'enabled' => true,
                    'keys' => [
                        'id' => 'f9877ea54b82afb2ceef',
                        'secret' => 'a9ba0ac82ffe0dbe8f82fd4544e43e9c21ece043',
                    ]
                ]
            ]
        ];
    }

    else
    {
        HttpClient\Util::redirect('http://localhost/missnorah/frontend.php');
    }

    try
    {

      // buit it functions of composer php

        $hybridauth = new Hybridauth($config);

        $hybridauth->authenticate(ucfirst($provider));

        $adapters = $hybridauth->getConnectedAdapters();

        $userInfo = $adapters[ucfirst($provider)]->getUserProfile();

      // variables which contain user data

        $email = $userInfo->email;
        $user_avatar = $userInfo->photoURL;
        




        $_SESSION["admin_email"] = $email;
        $_SESSION['admin_pic'] = $user_avatar;

        /**
        * Redirects user to home page after successful login attemp
        */
        HttpClient\Util::redirect('http://localhost/missnorah/userinfo.php');

    }
    catch (Exception $ee)
    {
        echo $ee->getMessage();
    }
?>
