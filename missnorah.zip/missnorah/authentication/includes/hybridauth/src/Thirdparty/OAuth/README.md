This package contains OAuth PHP Library.

OAuth PHP Library is an open source software available under the MIT License.

https://code.google.com/p/oauth/

http://oauth.googlecode.com/svn/code/php/LICENSE.txt
